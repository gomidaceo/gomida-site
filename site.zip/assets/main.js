(function(){
  var hd=document.getElementById('hd');
  if(hd&&!document.body.classList.contains('sub')){addEventListener('scroll',function(){hd.classList.toggle('solid',scrollY>40)},{passive:true});}
  var bg=document.getElementById('burger');
  if(bg)bg.onclick=function(){document.body.classList.toggle('open');bg.textContent=document.body.classList.contains('open')?'✕':'☰'};
  var g=document.getElementById('glow');
  if(g)addEventListener('pointermove',function(e){g.style.left=e.clientX+'px';g.style.top=e.clientY+'px'},{passive:true});
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;e.target.classList.add('in');
    e.target.querySelectorAll('[data-to]').forEach(function(el){var to=+el.dataset.to,suf=el.dataset.suf||'',i=0;var t=setInterval(function(){el.textContent=Math.min(i,to)+suf;if(i++>=to)clearInterval(t)},120)});
    io.unobserve(e.target)})},{threshold:.12});
  document.querySelectorAll('.reveal').forEach(function(el){io.observe(el)});
  var m=document.getElementById('morph');if(m)setInterval(function(){m.classList.toggle('go')},2400);
  var cmp=document.getElementById('cmp');
  if(cmp){var after=document.getElementById('after'),h=document.getElementById('handle'),drag=false;
    var set=function(x){var r=cmp.getBoundingClientRect();var p=Math.max(0,Math.min(1,(x-r.left)/r.width))*100;after.style.clipPath='inset(0 0 0 '+p+'%)';h.style.left=p+'%'};
    cmp.addEventListener('pointerdown',function(e){drag=true;set(e.clientX);cmp.setPointerCapture(e.pointerId)});
    cmp.addEventListener('pointermove',function(e){if(drag)set(e.clientX)});
    cmp.addEventListener('pointerup',function(){drag=false});}
  var reel=document.getElementById('reel');
  if(reel){document.getElementById('next').onclick=function(){reel.scrollBy({left:300,behavior:'smooth'})};document.getElementById('prev').onclick=function(){reel.scrollBy({left:-300,behavior:'smooth'})};}
  document.querySelectorAll('[data-filter]').forEach(function(wrap){
    wrap.querySelectorAll('a[data-f]').forEach(function(b){b.addEventListener('click',function(ev){ev.preventDefault();
      wrap.querySelectorAll('a[data-f]').forEach(function(x){x.classList.remove('on')});b.classList.add('on');
      var f=b.dataset.f;document.querySelectorAll('[data-c]').forEach(function(i){i.style.display=(f==='all'||i.dataset.c===f)?'':'none'})})})});
  var form=document.getElementById('qform');
  if(form)form.addEventListener('submit',function(e){e.preventDefault();var o=document.getElementById('qdone');if(o)o.style.display='block';form.reset()});
})();
(function(){
  var rm=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
  // neural network background
  var cv=document.getElementById('net');
  if(cv&&!rm){var cx=cv.getContext('2d'),W,H,pts=[],mx=-999,my=-999,dpr=Math.min(window.devicePixelRatio||1,2);
    function rs(){var r=cv.getBoundingClientRect();W=r.width;H=r.height;cv.width=W*dpr;cv.height=H*dpr;cx.setTransform(dpr,0,0,dpr,0,0);var n=Math.round(Math.min(70,W*H/16000));pts=[];for(var i=0;i<n;i++)pts.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.35,vy:(Math.random()-.5)*.35,c:Math.random()<.5?'245,165,36':(Math.random()<.5?'139,92,246':'34,211,238')})}
    rs();addEventListener('resize',rs);
    cv.parentNode.addEventListener('pointermove',function(e){var r=cv.getBoundingClientRect();mx=e.clientX-r.left;my=e.clientY-r.top});
    var vis=true;new IntersectionObserver(function(e){vis=e[0].isIntersecting}).observe(cv);
    (function tick(){if(vis&&!document.hidden){cx.clearRect(0,0,W,H);for(var i=0;i<pts.length;i++){var p=pts[i];p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>W)p.vx*=-1;if(p.y<0||p.y>H)p.vy*=-1;
      for(var j=i+1;j<pts.length;j++){var q=pts[j],dx=p.x-q.x,dy=p.y-q.y,d=dx*dx+dy*dy;if(d<14000){cx.strokeStyle='rgba('+p.c+','+(.18*(1-d/14000))+')';cx.lineWidth=1;cx.beginPath();cx.moveTo(p.x,p.y);cx.lineTo(q.x,q.y);cx.stroke()}}
      var md=(p.x-mx)*(p.x-mx)+(p.y-my)*(p.y-my);cx.fillStyle='rgba('+p.c+','+(md<20000?.95:.55)+')';cx.beginPath();cx.arc(p.x,p.y,md<20000?2.4:1.5,0,6.3);cx.fill()}}
      requestAnimationFrame(tick)})();}
  // console demo
  var con=document.getElementById('console');
  if(con&&!rm){
    var jobs=[
      {p:'화성 국밥집, 따뜻한 분위기, 15초 세로 광고',f:['김 오르는 뚝배기','사장님의 손','"오늘 저녁 한 그릇"','위치 · 영업시간']},
      {p:'동탄 네일샵, 오픈 이벤트, 감성 릴스',f:['반짝이는 손끝','이달의 디자인','"첫 방문 20%"','예약 링크']},
      {p:'수학학원, 겨울방학 특강, 신뢰감 있게',f:['칠판 위 공식','집중하는 학생','"겨울방학 특강"','상담 전화']},
      {p:'수제청 스마트스토어, 선물 시즌, 15초',f:['병에 담기는 청','리본 포장','"선물하기 좋은 날"','스토어 바로가기']}];
    var pr=document.getElementById('cPrompt'),bar=document.getElementById('cBar'),log=document.getElementById('cLog'),frs=[].slice.call(document.querySelectorAll('#cFrames .fr')),k=0;
    var logs=['▸ 프롬프트 분석 중…','▸ 업종·타깃 파악 완료','▸ 카피 3안 생성','▸ 장면 생성 SC 01','▸ 장면 생성 SC 02','▸ 장면 생성 SC 03','▸ 장면 생성 SC 04','▸ 자막 · 음악 합성','✓ RENDER COMPLETE · 15s · 1080×1920'];
    function sleep(ms){return new Promise(function(r){setTimeout(r,ms)})}
    async function run(){
      while(true){var j=jobs[k%jobs.length];k++;
        frs.forEach(function(f,i){f.classList.add('pending');f.querySelector('b').textContent=j.f[i]});
        bar.style.width='0%';log.textContent='▸ 대기 중';pr.textContent='';pr.classList.add('typing');
        for(var c=0;c<=j.p.length;c++){pr.textContent=j.p.slice(0,c);await sleep(55)}
        pr.classList.remove('typing');await sleep(400);
        for(var s=0;s<logs.length;s++){log.textContent=logs[s];bar.style.width=Math.round((s+1)/logs.length*100)+'%';
          if(s>=3&&s<=6)frs[s-3].classList.remove('pending');await sleep(s>=3&&s<=6?750:520)}
        await sleep(3200)}}
    var started=false;new IntersectionObserver(function(e){if(e[0].isIntersecting&&!started){started=true;run()}}).observe(con);
  }
})();
