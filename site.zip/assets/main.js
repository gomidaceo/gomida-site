(function(){
  var hd=document.getElementById('hd');
  if(hd&&!document.body.classList.contains('sub')){addEventListener('scroll',function(){hd.classList.toggle('solid',scrollY>40)},{passive:true});}
  var bg=document.getElementById('burger');
  if(bg)bg.onclick=function(){document.body.classList.toggle('open');bg.textContent=document.body.classList.contains('open')?'✕':'☰'};
  var g=document.getElementById('glow');
  if(g)addEventListener('pointermove',function(e){g.style.left=e.clientX+'px';g.style.top=e.clientY+'px'},{passive:true});
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;e.target.classList.add('in');
    e.target.querySelectorAll('[data-to]').forEach(function(el){var to=+el.dataset.to,suf=el.dataset.suf||'',i=0;var t=setInterval(function(){el.textContent=Math.min(i,to)+suf;if(i++>=to)clearInterval(t)},120)});
    io.unobserve(e.target)})},{threshold:.12});
  document.querySelectorAll('.reveal').forEach(function(el){io.observe(el)});
  var m=document.getElementById('morph');if(m)setInterval(function(){m.classList.toggle('go')},2400);
  var cmp=document.getElementById('cmp');
  if(cmp){var after=document.getElementById('after'),h=document.getElementById('handle'),drag=false;
    var set=function(x){var r=cmp.getBoundingClientRect();var p=Math.max(0,Math.min(1,(x-r.left)/r.width))*100;after.style.clipPath='inset(0 0 0 '+p+'%)';h.style.left=p+'%'};
    cmp.addEventListener('pointerdown',function(e){drag=true;set(e.clientX);cmp.setPointerCapture(e.pointerId)});
    cmp.addEventListener('pointermove',function(e){if(drag)set(e.clientX)});
    cmp.addEventListener('pointerup',function(){drag=false});}
  var reel=document.getElementById('reel');
  if(reel){document.getElementById('next').onclick=function(){reel.scrollBy({left:300,behavior:'smooth'})};document.getElementById('prev').onclick=function(){reel.scrollBy({left:-300,behavior:'smooth'})};}
  document.querySelectorAll('[data-filter]').forEach(function(wrap){
    wrap.querySelectorAll('a[data-f]').forEach(function(b){b.addEventListener('click',function(ev){ev.preventDefault();
      wrap.querySelectorAll('a[data-f]').forEach(function(x){x.classList.remove('on')});b.classList.add('on');
      var f=b.dataset.f;document.querySelectorAll('[data-c]').forEach(function(i){i.style.display=(f==='all'||i.dataset.c===f)?'':'none'})})})});
  var form=document.getElementById('qform');
  if(form)form.addEventListener('submit',function(e){e.preventDefault();var o=document.getElementById('qdone');if(o)o.style.display='block';form.reset()});
})();
(function(){
  var rm=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
  // neural network background
  var cv=document.getElementById('net');
  if(cv&&!rm){var cx=cv.getContext('2d'),W,H,pts=[],mx=-999,my=-999,dpr=Math.min(window.devicePixelRatio||1,2);
    function rs(){var r=cv.getBoundingClientRect();W=r.width;H=r.height;cv.width=W*dpr;cv.height=H*dpr;cx.setTransform(dpr,0,0,dpr,0,0);var n=Math.round(Math.min(70,W*H/16000));pts=[];for(var i=0;i<n;i++)pts.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.35,vy:(Math.random()-.5)*.35,c:Math.random()<.5?'245,165,36':(Math.random()<.5?'139,92,246':'34,211,238')})}
    rs();addEventListener('resize',rs);
    cv.parentNode.addEventListener('pointermove',function(e){var r=cv.getBoundingClientRect();mx=e.clientX-r.left;my=e.clientY-r.top});
    var vis=true;new IntersectionObserver(function(e){vis=e[0].isIntersecting}).observe(cv);
    (function tick(){if(vis&&!document.hidden){cx.clearRect(0,0,W,H);for(var i=0;i<pts.length;i++){var p=pts[i];p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>W)p.vx*=-1;if(p.y<0||p.y>H)p.vy*=-1;
      for(var j=i+1;j<pts.length;j++){var q=pts[j],dx=p.x-q.x,dy=p.y-q.y,d=dx*dx+dy*dy;if(d<14000){cx.strokeStyle='rgba('+p.c+','+(.18*(1-d/14000))+')';cx.lineWidth=1;cx.beginPath();cx.moveTo(p.x,p.y);cx.lineTo(q.x,q.y);cx.stroke()}}
      var md=(p.x-mx)*(p.x-mx)+(p.y-my)*(p.y-my);cx.fillStyle='rgba('+p.c+','+(md<20000?.95:.55)+')';cx.beginPath();cx.arc(p.x,p.y,md<20000?2.4:1.5,0,6.3);cx.fill()}}
      requestAnimationFrame(tick)})();}
  // console demo
  var con=document.getElementById('console');
  if(con&&!rm){
    var jobs=[
      {p:'화성 국밥집, 따뜻한 분위기, 15초 세로 광고',f:['김 오르는 뚝배기','사장님의 손','"오늘 저녁 한 그릇"','위치 · 영업시간']},
      {p:'동네 카페, 신메뉴 출시, 트렌디하게',f:['햇살 드는 카운터','크림 위 카라멜','"신메뉴 나왔어요"','오픈 시간']},
      {p:'동탄 네일샵, 오픈 이벤트, 감성 릴스',f:['반짝이는 손끝','이달의 디자인','"첫 방문 20%"','예약 링크']},
      {p:'수학학원, 겨울방학 특강, 신뢰감 있게',f:['눈 내리는 창가','공식 가득한 노트','"겨울방학 특강"','상담 전화']},
      {p:'수제청 스마트스토어, 선물 시즌, 15초',f:['병에 담긴 제철 과일','리본 포장','"선물하기 좋은 날"','스토어 바로가기']}];
    var IM=[];try{IM=JSON.parse(document.getElementById('conImgs').textContent)}catch(e){}
    var POS=['center 30%','center 60%','center 85%','center 10%'];
    var pr=document.getElementById('cPrompt'),bar=document.getElementById('cBar'),log=document.getElementById('cLog'),frs=[].slice.call(document.querySelectorAll('#cFrames .fr')),k=0;
    var logs=['▸ 프롬프트 분석 중…','▸ 업종·타깃 파악 완료','▸ 카피 3안 생성','▸ 장면 생성 SC 01','▸ 장면 생성 SC 02','▸ 장면 생성 SC 03','▸ 장면 생성 SC 04','▸ 자막 · 음악 합성','✓ RENDER COMPLETE · 15s · 1080×1920'];
    function sleep(ms){return new Promise(function(r){setTimeout(r,ms)})}
    async function run(){
      while(true){var j=jobs[k%jobs.length];k++;
        var ji=(k-1)%jobs.length;frs.forEach(function(f,i){f.classList.add('pending');f.querySelector('b').textContent=j.f[i];if(IM[ji]&&IM[ji][i]){f.style.backgroundImage='url('+IM[ji][i]+')';f.style.backgroundPosition=ji===0?'center':POS[i];f.style.backgroundSize=ji===0?'cover':(i%2?'190%':'150%')}});
        bar.style.width='0%';log.textContent='▸ 대기 중';pr.textContent='';pr.classList.add('typing');
        for(var c=0;c<=j.p.length;c++){pr.textContent=j.p.slice(0,c);await sleep(55)}
        pr.classList.remove('typing');await sleep(400);
        for(var s=0;s<logs.length;s++){log.textContent=logs[s];bar.style.width=Math.round((s+1)/logs.length*100)+'%';
          if(s>=3&&s<=6)frs[s-3].classList.remove('pending');await sleep(s>=3&&s<=6?750:520)}
        await sleep(3200)}}
    var started=false;new IntersectionObserver(function(e){if(e[0].isIntersecting&&!started){started=true;run()}}).observe(con);
  }
})();
(function(){
  // ---- AI planner ----
  document.querySelectorAll('.planner').forEach(function(root){
    var data=JSON.parse(root.querySelector('#plData').textContent);
    var form=root.querySelector('#plForm'),out=root.querySelector('#plOut');
    var MOOD={'따뜻한':{a:['따뜻한','정겨운','포근한'],bgm:'어쿠스틱 기타',v:'다정한 내레이션'},'트렌디한':{a:['힙한','감각적인','요즘 뜨는'],bgm:'경쾌한 시티팝',v:'톡톡 튀는 자막'},'고급스러운':{a:['품격 있는','특별한','프리미엄'],bgm:'잔잔한 피아노',v:'차분한 내레이션'},'유쾌한':{a:['신나는','기분 좋은','웃음 나는'],bgm:'통통 튀는 효과음',v:'유머 자막'},'신뢰감 있는':{a:['믿을 수 있는','꼼꼼한','검증된'],bgm:'담백한 피아노',v:'전문가 톤 내레이션'}};
    var GOAL={'신규 손님 모으기':{h:'처음 오시는 분, 환영해요',c:'지금 방문하기'},'이벤트 알리기':{h:'이번 주만 특별하게',c:'이벤트 확인하기'},'신메뉴·신상품':{h:'새로 나왔어요',c:'지금 만나보기'},'브랜드 알리기':{h:'우리 가게 이야기',c:'더 알아보기'}};
    var GR=['#ffb36b,#8a2a16','#f7b3c8,#4a2060','#9ad1ff,#14285f','#c7f0d0,#174a36','#f5a524,#3b1d6b','#e0c3ff,#3a1f6b'];
    function esc(t){return String(t).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
    function pick(a,i){return a[i%a.length]}
    var last='';
    form.addEventListener('submit',function(e){e.preventDefault();
      var ind=data.filter(function(x){return x.s===form.querySelector('#plInd').value})[0];
      var name=(form.querySelector('#plName').value.trim()||('우리 '+ind.n)).slice(0,20);
      var area=(form.querySelector('#plArea').value.trim()||'우리 동네').slice(0,10);
      var len=+form.querySelector('#plLen').value;
      var mood=form.querySelector('input[name=mood]:checked').value,goal=form.querySelector('input[name=goal]:checked').value;
      var M=MOOD[mood],G=GOAL[goal],seed=name.length+ind.n.length;
      var copies=[
        {t:'질문형 후킹',c:'"'+area+'에서 '+ind.w+' 고민될 땐? '+name+'!"'},
        {t:'감성형',c:'"'+pick(M.a,seed)+' '+ind.w+', '+name+'에서 만나요"'},
        {t:'행동 유도형',c:'"'+G.h+' — '+name+', '+G.c+'"'}];
      var sc=[
        {t:'0–3초',v:ind.d[0].replace(/ \d+초$/,''),cap:G.h,ai:'AI 장면 생성 · 후킹'},
        {t:'3–7초',v:ind.d[1],cap:'"'+ind.p[0]+'?"',ai:'고민 공감 자막'},
        {t:'7–11초',v:ind.d[2],cap:pick(M.a,seed+1)+' '+ind.w+', '+name,ai:'사진 기반 AI 합성'},
        {t:'11–15초',v:'로고 · 위치 · '+G.c,cap:area+' '+name+' · '+G.c,ai:'엔딩 카드'}];
      if(len===30){sc=[sc[0],sc[1],{t:'7–13초',v:'가게 분위기 · 디테일 컷',cap:pick(M.a,seed+2)+' 공간',ai:'AI 장면 생성'},sc[2],{t:'19–25초',v:'손님 반응 장면',cap:'"또 오고 싶어요"',ai:'AI 인물 연출 · 가상인물 표시'},sc[3]];
        var tt=['0–3초','3–7초','7–13초','13–19초','19–25초','25–30초'];sc.forEach(function(s,i){s.t=tt[i]})}
      var ch=len===15?['인스타 릴스','유튜브 쇼츠','틱톡']:['유튜브','인스타 피드','매장 TV'];
      var tag=['#'+area+ind.n.replace(/[·\s]/g,''),'#'+name.replace(/\s/g,''),'#'+area+'가볼만한곳'];
      last='[AI 기획기 결과]\n업종: '+ind.n+' / 가게: '+name+' / 지역: '+area+' / '+len+'초 / 분위기: '+mood+' / 목적: '+goal+'\n카피: '+copies.map(function(x){return x.c}).join(' | ');
      var logs=['▸ 업종 분석: '+ind.n,'▸ 타깃·목적 매칭: '+goal,'▸ 카피 3안 생성','▸ '+len+'초 콘티 '+sc.length+'컷 구성','✓ 기획 완료'];
      out.innerHTML='<div class="pl-log">'+logs.map(function(l,i){return '<span style="animation-delay:'+(i*.35)+'s">'+esc(l)+'</span>'}).join('')+'</div>';
      setTimeout(function(){
        var h='<div class="pl-res">';
        h+='<div class="pl-sec" style="animation-delay:0s"><h4>COPY · 광고 문구 3안</h4><div class="copy-list">'+copies.map(function(x){return '<div class="copy-item"><small>'+x.t+'</small>'+esc(x.c)+'</div>'}).join('')+'</div></div>';
        h+='<div class="pl-sec" style="animation-delay:.15s"><h4>STORYBOARD · '+len+'초 콘티</h4><div class="board">'+sc.map(function(s,i){return '<div class="sc"><div class="th" style="background:linear-gradient(170deg,'+GR[i%GR.length]+')"><span>SC '+String(i+1).padStart(2,'0')+' · '+s.t+'</span><b>'+esc(s.v)+'</b></div><div class="cap">'+esc(s.cap)+'<em>'+esc(s.ai)+'</em></div></div>'}).join('')+'</div></div>';
        h+='<div class="pl-sec" style="animation-delay:.3s"><h4>DIRECTION · 연출 제안</h4><div class="meta-row"><span>🎵 '+M.bgm+'</span><span>🎙 '+M.v+'</span>'+ch.map(function(c){return '<span>📱 '+c+'</span>'}).join('')+'</div></div>';
        h+='<div class="pl-sec" style="animation-delay:.45s"><h4>HASHTAG</h4><div class="meta-row">'+tag.map(function(t){return '<span>'+esc(t)+'</span>'}).join('')+'</div></div>';
        h+='<div class="pl-actions" style="animation-delay:.6s"><a class="btn btn-honey" id="plQuote" href="#">이 기획으로 제작 상담 →</a><button class="btn btn-ghost" type="button" id="plCopy">기획안 복사</button></div></div>';
        out.innerHTML=h;
        var q=root.dataset.quote+'?plan='+encodeURIComponent(last);out.querySelector('#plQuote').setAttribute('href',q);
        out.querySelector('#plCopy').addEventListener('click',function(){var b=this;try{navigator.clipboard.writeText(last).then(function(){b.textContent='복사됨 ✓'},function(){b.textContent='복사 실패'})}catch(err){b.textContent='복사 실패'}});
      },1900);
      if(window.innerWidth<980)out.scrollIntoView({behavior:'smooth',block:'start'});
    });
  });
  // prefill quote form from planner
  var m=document.getElementById('m');
  if(m&&location.search.indexOf('plan=')>-1){try{m.value=decodeURIComponent(location.search.split('plan=')[1].split('&')[0])}catch(e){}}
  // ---- Gomi assistant ----
  var gb=document.getElementById('gomiBtn');
  if(gb){var pn=document.getElementById('gomiPanel'),lg=document.getElementById('gomiLog');
    var A=['영상 길이와 장면 수에 따라 달라져요. AI 기획기로 원하는 광고를 먼저 그려 보시고, 견적 문의를 주시면 항목별로 정리해 드려요.','기획이 확정되면 15초 숏폼은 3일 안팎, 1분 브랜드 영상은 7~10일 정도 걸려요.','가게나 제품 사진 3~5장, 로고, 알리고 싶은 내용 한두 줄이면 충분해요. 없어도 상담하면서 함께 정리해요.','네! 고미다는 화성지역화폐 가맹점이라 카드, 계좌이체와 함께 지역화폐로도 결제하실 수 있어요.'];
    var Q=['비용은 얼마예요?','얼마나 걸려요?','뭘 준비하면 돼요?','지역화폐 돼요?'];
    function tog(o){pn.hidden=!o;gb.setAttribute('aria-expanded',o)}
    gb.addEventListener('click',function(){tog(pn.hidden)});
    document.getElementById('gomiX').addEventListener('click',function(){tog(false)});
    document.querySelectorAll('#gomiQ button').forEach(function(b){b.addEventListener('click',function(){var i=+b.dataset.a;
      var me=document.createElement('p');me.className='gp-me';me.textContent=Q[i];lg.appendChild(me);
      var bot=document.createElement('p');bot.className='gp-bot';bot.textContent='…';lg.appendChild(bot);lg.scrollTop=lg.scrollHeight;
      setTimeout(function(){bot.textContent=A[i];lg.scrollTop=lg.scrollHeight},600)})});
  }
})();
(function(){
  var rm=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
  // scroll progress
  var sp=document.getElementById('sprog');
  if(sp){var up=function(){var h=document.documentElement.scrollHeight-innerHeight;sp.style.width=(h>0?scrollY/h*100:0)+'%'};addEventListener('scroll',up,{passive:true});up();}
  // eyebrow decode
  if(!rm){var CH='01▓░▒<>/_#$%ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var io=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;io.unobserve(e.target);var el=e.target,fin=el.dataset.t,f=0,n=fin.length;
      var t=setInterval(function(){var o='';for(var i=0;i<n;i++){o+=(i<f/2||fin[i]===' ')?fin[i]:CH[Math.random()*CH.length|0]}el.textContent=o;if(f++>=n*2){clearInterval(t);el.textContent=fin}},28)})},{threshold:.6});
    document.querySelectorAll('.eyebrow').forEach(function(el){if(el.children.length||el.textContent.length>40)return;el.dataset.t=el.textContent;io.observe(el)});}
  // spotlight + tilt
  if(matchMedia('(hover:hover) and (pointer:fine)').matches){
    document.addEventListener('pointermove',function(e){var c=e.target.closest&&e.target.closest('.card,.stk,.shot');if(!c)return;var r=c.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;
      c.style.setProperty('--mx',x+'px');c.style.setProperty('--my',y+'px');
      if(c.classList.contains('shot')&&!rm)c.style.transform='perspective(800px) rotateY('+((x/r.width-.5)*8)+'deg) rotateX('+((.5-y/r.height)*8)+'deg)'},{passive:true});
    document.addEventListener('pointerout',function(e){var c=e.target.closest&&e.target.closest('.shot');if(c&&!c.contains(e.relatedTarget))c.style.transform=''});}
  // compare: auto sweep + scan follows handle
  var cmp=document.getElementById('cmp');
  if(cmp){var after=document.getElementById('after'),h=document.getElementById('handle');
    var setP=function(p){after.style.clipPath='inset(0 0 0 '+p+'%)';h.style.left=p+'%';cmp.style.setProperty('--hx',p+'%')};
    new MutationObserver(function(){cmp.style.setProperty('--hx',h.style.left||'50%')}).observe(h,{attributes:true,attributeFilter:['style']});
    var done=false,touched=false;cmp.addEventListener('pointerdown',function(){touched=true});
    new IntersectionObserver(function(es){if(!es[0].isIntersecting||done)return;done=true;if(rm)return;var t0=null;
      (function an(ts){if(touched)return;if(!t0)t0=ts;var k=Math.min(1,(ts-t0)/2600),E=function(q){return 1-Math.pow(1-q,3)};
        var p=k<.55?100-E(k/.55)*92:8+E((k-.55)/.45)*42;setP(Math.max(0,Math.min(100,p)));if(k<1)requestAnimationFrame(an)})(performance.now());
    },{threshold:.5}).observe(cmp);}
})();
