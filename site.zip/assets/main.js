(function(){
  var hd=document.getElementById('hd');
  if(hd&&!document.body.classList.contains('sub')){addEventListener('scroll',function(){hd.classList.toggle('solid',scrollY>40)},{passive:true});}
  var bg=document.getElementById('burger');
  if(bg)bg.onclick=function(){document.body.classList.toggle('open');bg.textContent=document.body.classList.contains('open')?'✕':'☰'};
  var g=document.getElementById('glow');
  if(g)addEventListener('pointermove',function(e){g.style.left=e.clientX+'px';g.style.top=e.clientY+'px'},{passive:true});
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;e.target.classList.add('in');
    e.target.querySelectorAll('[data-to]').forEach(function(el){var to=+el.dataset.to,suf=el.dataset.suf||'',i=0;var t=setInterval(function(){el.textContent=Math.min(i,to)+suf;if(i++>=to)clearInterval(t)},120)});
    io.unobserve(e.target)})},{threshold:.12});
  document.querySelectorAll('.reveal').forEach(function(el){io.observe(el)});
  var m=document.getElementById('morph');if(m)setInterval(function(){m.classList.toggle('go')},2400);
  var cmp=document.getElementById('cmp');
  if(cmp){var after=document.getElementById('after'),h=document.getElementById('handle'),drag=false;
    var set=function(x){var r=cmp.getBoundingClientRect();var p=Math.max(0,Math.min(1,(x-r.left)/r.width))*100;after.style.clipPath='inset(0 0 0 '+p+'%)';h.style.left=p+'%'};
    cmp.addEventListener('pointerdown',function(e){drag=true;set(e.clientX);cmp.setPointerCapture(e.pointerId)});
    cmp.addEventListener('pointermove',function(e){if(drag)set(e.clientX)});
    cmp.addEventListener('pointerup',function(){drag=false});}
  var reel=document.getElementById('reel');
  if(reel){document.getElementById('next').onclick=function(){reel.scrollBy({left:300,behavior:'smooth'})};document.getElementById('prev').onclick=function(){reel.scrollBy({left:-300,behavior:'smooth'})};}
  document.querySelectorAll('[data-filter]').forEach(function(wrap){
    wrap.querySelectorAll('a[data-f]').forEach(function(b){b.addEventListener('click',function(ev){ev.preventDefault();
      wrap.querySelectorAll('a[data-f]').forEach(function(x){x.classList.remove('on')});b.classList.add('on');
      var f=b.dataset.f;document.querySelectorAll('[data-c]').forEach(function(i){i.style.display=(f==='all'||i.dataset.c===f)?'':'none'})})})});
  var form=document.getElementById('qform');
  if(form)form.addEventListener('submit',function(e){e.preventDefault();var o=document.getElementById('qdone');if(o)o.style.display='block';form.reset()});
})();
