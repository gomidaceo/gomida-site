(function(){
  var hd=document.getElementById('hd');
  if(hd&&!document.body.classList.contains('sub')){addEventListener('scroll',function(){hd.classList.toggle('solid',scrollY>40)},{passive:true});}
  var bg=document.getElementById('burger');
  if(bg)bg.onclick=function(){document.body.classList.toggle('open');bg.textContent=document.body.classList.contains('open')?'✕':'☰'};
  var g=document.getElementById('glow');
  if(g)addEventListener('pointermove',function(e){g.style.left=e.clientX+'px';g.style.top=e.clientY+'px'},{passive:true});
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;e.target.classList.add('in');
    e.target.querySelectorAll('[data-to]').forEach(function(el){var to=+el.dataset.to,suf=el.dataset.suf||'',i=0;var t=setInterval(function(){el.textContent=Math.min(i,to)+suf;if(i++>=to)clearInterval(t)},120)});
    io.unobserve(e.target)})},{threshold:.12});
  document.querySelectorAll('.reveal').forEach(function(el){io.observe(el)});
  var m=document.getElementById('morph');if(m)setInterval(function(){m.classList.toggle('go')},2400);
  var cmp=document.getElementById('cmp');
  if(cmp){var after=document.getElementById('after'),h=document.getElementById('handle'),drag=false;
    var set=function(x){var r=cmp.getBoundingClientRect();var p=Math.max(0,Math.min(1,(x-r.left)/r.width))*100;after.style.clipPath='inset(0 0 0 '+p+'%)';h.style.left=p+'%'};
    cmp.addEventListener('pointerdown',function(e){drag=true;set(e.clientX);cmp.setPointerCapture(e.pointerId)});
    cmp.addEventListener('pointermove',function(e){if(drag)set(e.clientX)});
    cmp.addEventListener('pointerup',function(){drag=false});}
  var reel=document.getElementById('reel');
  if(reel){document.getElementById('next').onclick=function(){reel.scrollBy({left:300,behavior:'smooth'})};document.getElementById('prev').onclick=function(){reel.scrollBy({left:-300,behavior:'smooth'})};}
  document.querySelectorAll('[data-filter]').forEach(function(wrap){
    wrap.querySelectorAll('a[data-f]').forEach(function(b){b.addEventListener('click',function(ev){ev.preventDefault();
      wrap.querySelectorAll('a[data-f]').forEach(function(x){x.classList.remove('on')});b.classList.add('on');
      var f=b.dataset.f;document.querySelectorAll('[data-c]').forEach(function(i){i.style.display=(f==='all'||i.dataset.c===f)?'':'none'})})})});
  var form=document.getElementById('qform');
  
})();
(function(){
  var rm=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
  // neural network background
  var cv=document.getElementById('net');
  if(cv&&!rm){var cx=cv.getContext('2d'),W,H,pts=[],mx=-999,my=-999,dpr=Math.min(window.devicePixelRatio||1,2);
    function rs(){var r=cv.getBoundingClientRect();W=r.width;H=r.height;cv.width=W*dpr;cv.height=H*dpr;cx.setTransform(dpr,0,0,dpr,0,0);var n=Math.round(Math.min(70,W*H/16000));pts=[];for(var i=0;i<n;i++)pts.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.35,vy:(Math.random()-.5)*.35,c:Math.random()<.5?'245,165,36':(Math.random()<.5?'139,92,246':'34,211,238')})}
    rs();addEventListener('resize',rs);
    cv.parentNode.addEventListener('pointermove',function(e){var r=cv.getBoundingClientRect();mx=e.clientX-r.left;my=e.clientY-r.top});
    var vis=true;new IntersectionObserver(function(e){vis=e[0].isIntersecting}).observe(cv);
    (function tick(){if(vis&&!document.hidden){cx.clearRect(0,0,W,H);for(var i=0;i<pts.length;i++){var p=pts[i];p.x+=p.vx;p.y+=p.vy;if(p.x<0||p.x>W)p.vx*=-1;if(p.y<0||p.y>H)p.vy*=-1;
      for(var j=i+1;j<pts.length;j++){var q=pts[j],dx=p.x-q.x,dy=p.y-q.y,d=dx*dx+dy*dy;if(d<14000){cx.strokeStyle='rgba('+p.c+','+(.18*(1-d/14000))+')';cx.lineWidth=1;cx.beginPath();cx.moveTo(p.x,p.y);cx.lineTo(q.x,q.y);cx.stroke()}}
      var md=(p.x-mx)*(p.x-mx)+(p.y-my)*(p.y-my);cx.fillStyle='rgba('+p.c+','+(md<20000?.95:.55)+')';cx.beginPath();cx.arc(p.x,p.y,md<20000?2.4:1.5,0,6.3);cx.fill()}}
      requestAnimationFrame(tick)})();}
  // console demo
  var con=document.getElementById('console');
  if(con&&!rm){
    var jobs=[
      {p:'동탄 네일샵, 오픈 이벤트, 감성 릴스',f:['반짝이는 손끝','정성 시술','"이달의 디자인"','첫 방문 20%']},
      {p:'화성 국밥집, 따뜻한 분위기, 15초 세로 광고',f:['김 오르는 뚝배기','사장님의 손','"오늘 저녁 한 그릇"','위치 · 영업시간']},
      {p:'동네 카페, 신메뉴 출시, 트렌디하게',f:['햇살 드는 카운터','크림 위 카라멜','"신메뉴 나왔어요"','오픈 시간']},
      {p:'수학학원, 겨울방학 특강, 신뢰감 있게',f:['눈 내리는 창가','공식 가득한 노트','"겨울방학 특강"','상담 전화']},
      {p:'수제청 스마트스토어, 선물 시즌, 15초',f:['병에 담긴 제철 과일','리본 포장','"선물하기 좋은 날"','스토어 바로가기']}];
    var IM=[];try{IM=JSON.parse(document.getElementById('conImgs').textContent)}catch(e){}
    var POS=['center 30%','center 60%','center 85%','center 10%'];
    var pr=document.getElementById('cPrompt'),bar=document.getElementById('cBar'),log=document.getElementById('cLog'),frs=[].slice.call(document.querySelectorAll('#cFrames .fr')),k=0;
    var logs=['▸ 프롬프트 분석 중…','▸ 업종·타깃 파악 완료','▸ 카피 3안 생성','▸ 장면 생성 SC 01','▸ 장면 생성 SC 02','▸ 장면 생성 SC 03','▸ 장면 생성 SC 04','▸ 자막 · 음악 합성','✓ RENDER COMPLETE · 15s · 1080×1920'];
    function sleep(ms){return new Promise(function(r){setTimeout(r,ms)})}
    async function run(){
      while(true){var j=jobs[k%jobs.length];k++;
        var ji=(k-1)%jobs.length;frs.forEach(function(f,i){f.classList.add('pending');f.querySelector('b').textContent=j.f[i];if(IM[ji]&&IM[ji][i]){f.style.backgroundImage='url('+IM[ji][i]+')';f.style.backgroundPosition=ji<2?'center':POS[i];f.style.backgroundSize=ji<2?'cover':(i%2?'190%':'150%')}});
        bar.style.width='0%';log.textContent='▸ 대기 중';pr.textContent='';pr.classList.add('typing');
        for(var c=0;c<=j.p.length;c++){pr.textContent=j.p.slice(0,c);await sleep(55)}
        pr.classList.remove('typing');await sleep(400);
        for(var s=0;s<logs.length;s++){log.textContent=logs[s];bar.style.width=Math.round((s+1)/logs.length*100)+'%';
          if(s>=3&&s<=6)frs[s-3].classList.remove('pending');await sleep(s>=3&&s<=6?750:520)}
        await sleep(3200)}}
    var started=false;new IntersectionObserver(function(e){if(e[0].isIntersecting&&!started){started=true;run()}}).observe(con);
  }
})();
(function(){
  // ---- AI planner ----
  document.querySelectorAll('.planner').forEach(function(root){
    var data=JSON.parse(root.querySelector('#plData').textContent);
    var form=root.querySelector('#plForm'),out=root.querySelector('#plOut');
    var MOOD={'따뜻한':{a:['따뜻한','정겨운','포근한'],bgm:'어쿠스틱 기타',v:'다정한 내레이션'},'트렌디한':{a:['힙한','감각적인','요즘 뜨는'],bgm:'경쾌한 시티팝',v:'톡톡 튀는 자막'},'고급스러운':{a:['품격 있는','특별한','프리미엄'],bgm:'잔잔한 피아노',v:'차분한 내레이션'},'유쾌한':{a:['신나는','기분 좋은','웃음 나는'],bgm:'통통 튀는 효과음',v:'유머 자막'},'신뢰감 있는':{a:['믿을 수 있는','꼼꼼한','검증된'],bgm:'담백한 피아노',v:'전문가 톤 내레이션'}};
    var GOAL={'신규 손님 모으기':{h:'처음 오시는 분, 환영해요',c:'지금 방문하기'},'이벤트 알리기':{h:'이번 주만 특별하게',c:'이벤트 확인하기'},'신메뉴·신상품':{h:'새로 나왔어요',c:'지금 만나보기'},'브랜드 알리기':{h:'우리 가게 이야기',c:'더 알아보기'}};
    var GR=['#ffb36b,#8a2a16','#f7b3c8,#4a2060','#9ad1ff,#14285f','#c7f0d0,#174a36','#f5a524,#3b1d6b','#e0c3ff,#3a1f6b'];
    function esc(t){return String(t).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
    function pick(a,i){return a[i%a.length]}
    var last='';
    form.addEventListener('submit',function(e){e.preventDefault();
      var ind=data.filter(function(x){return x.s===form.querySelector('#plInd').value})[0];
      var name=(form.querySelector('#plName').value.trim()||('우리 '+ind.n)).slice(0,20);
      var area=(form.querySelector('#plArea').value.trim()||'우리 동네').slice(0,10);
      var len=+form.querySelector('#plLen').value;
      var mood=form.querySelector('input[name=mood]:checked').value,goal=form.querySelector('input[name=goal]:checked').value;
      var M=MOOD[mood],G=GOAL[goal],seed=name.length+ind.n.length;
      var copies=[
        {t:'질문형 후킹',c:'"'+area+'에서 '+ind.w+' 고민될 땐? '+name+'!"'},
        {t:'감성형',c:'"'+pick(M.a,seed)+' '+ind.w+', '+name+'에서 만나요"'},
        {t:'행동 유도형',c:'"'+G.h+' — '+name+', '+G.c+'"'}];
      var sc=[
        {t:'0–3초',v:ind.d[0].replace(/ \d+초$/,''),cap:G.h,ai:'AI 장면 생성 · 후킹'},
        {t:'3–7초',v:ind.d[1],cap:'"'+ind.p[0]+'?"',ai:'고민 공감 자막'},
        {t:'7–11초',v:ind.d[2],cap:pick(M.a,seed+1)+' '+ind.w+', '+name,ai:'사진 기반 AI 합성'},
        {t:'11–15초',v:'로고 · 위치 · '+G.c,cap:area+' '+name+' · '+G.c,ai:'엔딩 카드'}];
      if(len===30){sc=[sc[0],sc[1],{t:'7–13초',v:'가게 분위기 · 디테일 컷',cap:pick(M.a,seed+2)+' 공간',ai:'AI 장면 생성'},sc[2],{t:'19–25초',v:'손님 반응 장면',cap:'"또 오고 싶어요"',ai:'AI 인물 연출 · 가상인물 표시'},sc[3]];
        var tt=['0–3초','3–7초','7–13초','13–19초','19–25초','25–30초'];sc.forEach(function(s,i){s.t=tt[i]})}
      var ch=len===15?['인스타 릴스','유튜브 쇼츠','틱톡']:['유튜브','인스타 피드','매장 TV'];
      var tag=['#'+area+ind.n.replace(/[·\s]/g,''),'#'+name.replace(/\s/g,''),'#'+area+'가볼만한곳'];
      last='[AI 기획기 결과]\n업종: '+ind.n+' / 가게: '+name+' / 지역: '+area+' / '+len+'초 / 분위기: '+mood+' / 목적: '+goal+'\n카피: '+copies.map(function(x){return x.c}).join(' | ');
      var logs=['▸ 업종 분석: '+ind.n,'▸ 타깃·목적 매칭: '+goal,'▸ 카피 3안 생성','▸ '+len+'초 콘티 '+sc.length+'컷 구성','✓ 기획 완료'];
      out.innerHTML='<div class="pl-log">'+logs.map(function(l,i){return '<span style="animation-delay:'+(i*.35)+'s">'+esc(l)+'</span>'}).join('')+'</div>';
      setTimeout(function(){
        var h='<div class="pl-res">';
        h+='<div class="pl-sec" style="animation-delay:0s"><h4>COPY · 광고 문구 3안</h4><div class="copy-list">'+copies.map(function(x){return '<div class="copy-item"><small>'+x.t+'</small>'+esc(x.c)+'</div>'}).join('')+'</div></div>';
        h+='<div class="pl-sec" style="animation-delay:.15s"><h4>STORYBOARD · '+len+'초 콘티</h4><div class="board">'+sc.map(function(s,i){return '<div class="sc"><div class="th" style="background:linear-gradient(170deg,'+GR[i%GR.length]+')"><span>SC '+String(i+1).padStart(2,'0')+' · '+s.t+'</span><b>'+esc(s.v)+'</b></div><div class="cap">'+esc(s.cap)+'<em>'+esc(s.ai)+'</em></div></div>'}).join('')+'</div></div>';
        h+='<div class="pl-sec" style="animation-delay:.3s"><h4>DIRECTION · 연출 제안</h4><div class="meta-row"><span>🎵 '+M.bgm+'</span><span>🎙 '+M.v+'</span>'+ch.map(function(c){return '<span>📱 '+c+'</span>'}).join('')+'</div></div>';
        h+='<div class="pl-sec" style="animation-delay:.45s"><h4>HASHTAG</h4><div class="meta-row">'+tag.map(function(t){return '<span>'+esc(t)+'</span>'}).join('')+'</div></div>';
        h+='<div class="pl-actions" style="animation-delay:.6s"><a class="btn btn-honey" id="plQuote" href="#">이 기획으로 제작 상담 →</a><button class="btn btn-ghost" type="button" id="plCopy">기획안 복사</button></div></div>';
        out.innerHTML=h;
        var q=root.dataset.quote+'?plan='+encodeURIComponent(last);out.querySelector('#plQuote').setAttribute('href',q);
        out.querySelector('#plCopy').addEventListener('click',function(){var b=this;try{navigator.clipboard.writeText(last).then(function(){b.textContent='복사됨 ✓'},function(){b.textContent='복사 실패'})}catch(err){b.textContent='복사 실패'}});
      },1900);
      if(window.innerWidth<980)out.scrollIntoView({behavior:'smooth',block:'start'});
    });
  });
  // prefill quote form from planner
  var m=document.getElementById('m');
  if(m&&location.search.indexOf('plan=')>-1){try{m.value=decodeURIComponent(location.search.split('plan=')[1].split('&')[0])}catch(e){}}
  // ---- Gomi assistant ----
  var gb=document.getElementById('gomiBtn');
  if(gb){var pn=document.getElementById('gomiPanel'),lg=document.getElementById('gomiLog');
    var A=['영상 길이와 장면 수에 따라 달라져요. AI 기획기로 원하는 광고를 먼저 그려 보시고, 견적 문의를 주시면 항목별로 정리해 드려요.','기획이 확정되면 15초 숏폼은 3일 안팎, 1분 브랜드 영상은 7~10일 정도 걸려요.','가게나 제품 사진 3~5장, 로고, 알리고 싶은 내용 한두 줄이면 충분해요. 없어도 상담하면서 함께 정리해요.','네! 고미다는 화성지역화폐 가맹점이라 카드, 계좌이체와 함께 지역화폐로도 결제하실 수 있어요.'];
    var Q=['비용은 얼마예요?','얼마나 걸려요?','뭘 준비하면 돼요?','지역화폐 돼요?'];
    function tog(o){pn.hidden=!o;gb.setAttribute('aria-expanded',o)}
    gb.addEventListener('click',function(){tog(pn.hidden)});
    document.getElementById('gomiX').addEventListener('click',function(){tog(false)});
    document.querySelectorAll('#gomiQ button').forEach(function(b){b.addEventListener('click',function(){var i=+b.dataset.a;
      var me=document.createElement('p');me.className='gp-me';me.textContent=Q[i];lg.appendChild(me);
      var bot=document.createElement('p');bot.className='gp-bot';bot.textContent='…';lg.appendChild(bot);lg.scrollTop=lg.scrollHeight;
      setTimeout(function(){bot.textContent=A[i];lg.scrollTop=lg.scrollHeight},600)})});
  }
})();
(function(){
  var rm=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
  // scroll progress
  var sp=document.getElementById('sprog');
  if(sp){var up=function(){var h=document.documentElement.scrollHeight-innerHeight;sp.style.width=(h>0?scrollY/h*100:0)+'%'};addEventListener('scroll',up,{passive:true});up();}
  // eyebrow decode
  if(!rm){var CH='01▓░▒<>/_#$%ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var io=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;io.unobserve(e.target);var el=e.target,fin=el.dataset.t,f=0,n=fin.length;
      var t=setInterval(function(){var o='';for(var i=0;i<n;i++){o+=(i<f/2||fin[i]===' ')?fin[i]:CH[Math.random()*CH.length|0]}el.textContent=o;if(f++>=n*2){clearInterval(t);el.textContent=fin}},28)})},{threshold:.6});
    document.querySelectorAll('.eyebrow').forEach(function(el){if(el.children.length||el.textContent.length>40)return;el.dataset.t=el.textContent;io.observe(el)});}
  // spotlight + tilt
  if(matchMedia('(hover:hover) and (pointer:fine)').matches){
    document.addEventListener('pointermove',function(e){var c=e.target.closest&&e.target.closest('.card,.stk,.shot');if(!c)return;var r=c.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;
      c.style.setProperty('--mx',x+'px');c.style.setProperty('--my',y+'px');
      if(c.classList.contains('shot')&&!rm)c.style.transform='perspective(800px) rotateY('+((x/r.width-.5)*8)+'deg) rotateX('+((.5-y/r.height)*8)+'deg)'},{passive:true});
    document.addEventListener('pointerout',function(e){var c=e.target.closest&&e.target.closest('.shot');if(c&&!c.contains(e.relatedTarget))c.style.transform=''});}
  // compare: auto sweep + scan follows handle
  var cmp=document.getElementById('cmp');
  if(cmp){var after=document.getElementById('after'),h=document.getElementById('handle');
    var setP=function(p){after.style.clipPath='inset(0 0 0 '+p+'%)';h.style.left=p+'%';cmp.style.setProperty('--hx',p+'%')};
    new MutationObserver(function(){cmp.style.setProperty('--hx',h.style.left||'50%')}).observe(h,{attributes:true,attributeFilter:['style']});
    var done=false,touched=false;cmp.addEventListener('pointerdown',function(){touched=true});
    new IntersectionObserver(function(es){if(!es[0].isIntersecting||done)return;done=true;if(rm)return;var t0=null;
      (function an(ts){if(touched)return;if(!t0)t0=ts;var k=Math.min(1,(ts-t0)/2600),E=function(q){return 1-Math.pow(1-q,3)};
        var p=k<.55?100-E(k/.55)*92:8+E((k-.55)/.45)*42;setP(Math.max(0,Math.min(100,p)));if(k<1)requestAnimationFrame(an)})(performance.now());
    },{threshold:.5}).observe(cmp);}
})();
(function(){
  var ph=document.getElementById('phone');if(!ph)return;
  var SETS=[];try{SETS=JSON.parse(document.getElementById('plSets').textContent)}catch(e){}
  var all=[].slice.call(ph.querySelectorAll('.ph-sl')),sg=[].slice.call(ph.querySelectorAll('.ph-segs i')),sub=document.getElementById('phSub'),cta=document.getElementById('phCta'),
      li=[].slice.call(document.querySelectorAll('#plScenes li')),tabs=[].slice.call(document.querySelectorAll('#plTabs button')),pp=document.getElementById('phPP'),
      sl=all,cur=0,k=0,tm=null,vis=false,paused=false,left=3750,t0=Date.now(),on=false;
  function useSet(si){if(!SETS.length)return;cur=si;var S=SETS[si];sl=all.filter(function(x){return x.dataset.set===S.k});all.forEach(function(x){x.classList.remove('on')});
    li.forEach(function(l,i){var c=S.sc[i]||['',''];l.querySelector('b').textContent=c[0];l.querySelector('small').textContent=c[1]});
    if(cta)cta.textContent=S.cta;tabs.forEach(function(t,i){t.classList.toggle('on',i===si);t.setAttribute('aria-selected',i===si)})}
  function show(n){k=n;sl.forEach(function(s,i){s.classList.toggle('on',i===n)});
    sg.forEach(function(s,i){s.classList.remove('cur');s.classList.toggle('done',i<n)});void ph.offsetWidth;sg[n].classList.add('cur');
    li.forEach(function(l,i){l.classList.toggle('on',i===n)});
    sub.classList.add('swap');sub.textContent=sl[n].dataset.sub;void sub.offsetWidth;sub.classList.remove('swap');
    ph.className='phone s'+n+' set-'+(SETS[cur]?SETS[cur].k:'x')+(paused?' paused':'')+(ph.dataset.snd==='1'?' snd':'');try{ph.dispatchEvent(new CustomEvent('scene',{detail:n}))}catch(e){}}
  function next(){if(k+1>=sl.length){useSet((cur+1)%Math.max(1,SETS.length));show(0)}else show(k+1)}
  function sched(ms){clearTimeout(tm);t0=Date.now();left=ms;tm=setTimeout(function(){next();sched(3750)},ms)}
  function run(){if(vis&&!paused){if(!on){on=true;sched(left)}}else if(on){on=false;clearTimeout(tm);left=Math.max(200,left-(Date.now()-t0))}}
  pp.onclick=function(){paused=!paused;ph.classList.toggle('paused',paused);pp.textContent=paused?'▶':'❚❚';pp.setAttribute('aria-label',paused?'재생':'일시정지');if(paused){if(on){on=false;clearTimeout(tm);left=Math.max(200,left-(Date.now()-t0))}}else run()};
  tabs.forEach(function(t,i){t.onclick=function(){useSet(i);show(0);left=3750;if(on)sched(3750)}});
  ph._restart=function(){show(0);if(on){sched(3750)}};
  useSet(0);show(0);
  new IntersectionObserver(function(e){vis=e[0].isIntersecting;ph.classList.toggle('paused',!vis||paused);run()},{threshold:.3}).observe(ph);
})();
(function(){
  var rm=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;if(rm)return;
  function load(v){if(!v.src&&v.dataset.src){v.src=v.dataset.src;v.addEventListener('playing',function(){v.classList.add('ok')},{once:true})}}
  function play(v){load(v);var p=v.play();if(p&&p.catch)p.catch(function(){})}
  // background videos (compare + work cards): play while visible
  var bg=[].slice.call(document.querySelectorAll('.cmp-vid,.shot .sv'));
  if(bg.length){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting)play(e.target);else if(e.target.src)e.target.pause()})},{threshold:.25});
    bg.forEach(function(v){io.observe(v);if(v.classList.contains('cmp-vid'))v.parentNode.classList.add('vid')});}
  // phone player: play active slide video
  var ph=document.getElementById('phone');if(!ph)return;
  var vids=[].slice.call(ph.querySelectorAll('.ph-sl video'));if(!vids.length)return;
  vids.forEach(function(v){v.parentNode.classList.add('vid')});
  load(vids[0]);
  new MutationObserver(function(){var vis=!ph.classList.contains('paused');
    vids.forEach(function(v){var on=v.parentNode.classList.contains('on');
      if(on&&vis){if(v.dataset.cur!=='1'){v.dataset.cur='1';try{v.currentTime=0}catch(e){}}play(v)}else{v.pause();if(!on)v.dataset.cur='0'}});
    var on=ph.querySelector('.ph-sl.on');var nx=on&&on.nextElementSibling;if(!nx||!nx.classList.contains('ph-sl'))nx=ph.querySelector('.ph-sl');var nv=nx&&nx.querySelector('video');if(nv)load(nv);
  }).observe(ph,{attributes:true,attributeFilter:['class']});
})();

(function(){
  // sound: real BGM file (royalty-free) synced to the 15s preview
  var ph=document.getElementById('phone'),btn=document.getElementById('phSnd');if(!ph||!btn)return;
  var src=ph.dataset.bgm;if(!src){btn.remove();return}
  var a=new Audio();a.preload='none';a.loop=true;var on=false,fade=null;
  function vol(to,cb){clearInterval(fade);fade=setInterval(function(){var v=a.volume+(to>a.volume?.05:-.05);if((to>a.volume&&v>=to)||(to<a.volume&&v<=to)){v=to;clearInterval(fade);if(cb)cb()}a.volume=Math.max(0,Math.min(1,v))},40)}
  function play(){if(!a.src)a.src=src;a.volume=0;var p=a.play();if(p&&p.catch)p.catch(function(){});vol(.7)}
  new MutationObserver(function(){if(!on)return;if(ph.classList.contains('paused'))a.pause();else if(a.paused)play()}).observe(ph,{attributes:true,attributeFilter:['class']});
  btn.onclick=function(){on=!on;ph.dataset.snd=on?'1':'0';btn.textContent=on?'🔊 음악 끄기':'🎵 음악 켜기';btn.setAttribute('aria-pressed',on);ph.classList.toggle('snd',on);
    if(on){try{a.currentTime=0}catch(e){}play();if(ph._restart)ph._restart()}else vol(0,function(){a.pause()})};
})();
(function(){
  // compare: switch sets (beauty / food)
  var tb=[].slice.call(document.querySelectorAll('#cmpTabs button'));if(tb.length<2)return;
  var S=[];try{S=JSON.parse(document.getElementById('cmpSets').textContent)}catch(e){return}
  var B=document.getElementById('cmpB'),A=document.getElementById('after'),V=A.querySelector('.cmp-vid'),O=document.getElementById('cmpObj'),sm=document.getElementById('cmpSm'),bg=document.getElementById('cmpBig');
  tb.forEach(function(t,i){t.onclick=function(){var c=S[i];tb.forEach(function(x,j){x.classList.toggle('on',j===i);x.setAttribute('aria-selected',j===i)});
    B.style.backgroundImage='url('+c.before+')';A.style.backgroundImage='url('+c.after+')';O.textContent=c.obj;sm.textContent=c.sm;bg.innerHTML=c.big;
    if(V){V.classList.remove('ok');V.dataset.src=c.vid;V.removeAttribute('src');V.load();V.src=c.vid;V.addEventListener('playing',function(){V.classList.add('ok')},{once:true});var p=V.play();if(p&&p.catch)p.catch(function(){})}}});
})();

(function(){
  // ---- 견적 문의 접수 + 문의 게시판 (Google Apps Script) ----
  var form=document.getElementById('qform'),bd=document.getElementById('bd');
  var API=(form&&form.dataset.api)||(bd&&bd.dataset.api)||'';
  function esc(t){return String(t==null?'':t).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  async function hash(pw){try{var b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode('gomida:'+pw));return Array.from(new Uint8Array(b)).map(function(x){return x.toString(16).padStart(2,'0')}).join('')}catch(e){return 'p:'+pw}}
  function val(id){var el=document.getElementById(id);return el?el.value.trim():''}
  if(form){
    var done=document.getElementById('qdone'),send=document.getElementById('qsend');
    if(!API){done.style.display='block';done.textContent='온라인 접수를 준비하고 있어요. 지금은 전화나 카카오톡으로 문의해 주세요.';if(send)send.disabled=true}
    form.addEventListener('submit',async function(e){e.preventDefault();if(!API)return;
      var pw=val('pw');if(pw.length<4){done.style.display='block';done.textContent='글 비밀번호를 4자리 이상 입력해 주세요.';return}
      var svc=val('s'),ind=val('i');
      var d={name:val('n'),tel:val('t'),svc:svc,ind:ind,len:val('l'),date:val('d'),msg:val('m'),hp:val('hp'),pw:await hash(pw),title:'['+(svc||'견적')+'] '+(ind&&ind!=='기타'?ind+' ':'')+'문의드립니다'};
      send.disabled=true;send.textContent='보내는 중…';done.style.display='block';done.textContent='';
      try{var r=await fetch(API,{method:'POST',body:JSON.stringify(d)});var j=await r.json();
        form.dispatchEvent(new CustomEvent('qresult',{detail:j}));if(j.ok){done.textContent='✓ 문의가 접수됐어요 (게시글 #'+j.no+'). 빠른 시일 내에 연락드릴게요. 아래 게시판에서 비밀번호로 답변을 확인할 수 있어요.';form.reset();loadBoard()}
        else done.textContent=j.error||'접수에 실패했어요. 전화나 카카오톡으로 문의해 주세요.'}
      catch(err){form.dispatchEvent(new CustomEvent('qresult',{detail:{ok:false}}));done.textContent='접수에 실패했어요. 인터넷 연결을 확인하시거나 전화·카카오톡으로 문의해 주세요.'}
      send.disabled=false;send.textContent='문의 남기기 →'});
  }
  var list=document.getElementById('bdList'),ALL=[],F='all',PWS={};
  var ADM='';try{ADM=sessionStorage.getItem('gmdAdm')||''}catch(e){}
  var LOCK='<svg class="bd-lock" viewBox="0 0 16 16" aria-hidden="true"><rect x="3" y="7" width="10" height="7" rx="2"/><path d="M5.5 7V5a2.5 2.5 0 0 1 5 0v2" fill="none"/></svg>';
  var BEAR='<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="16" cy="16" r="9" fill="#f5a524"/><circle cx="48" cy="16" r="9" fill="#f5a524"/><circle cx="32" cy="36" r="24" fill="#f5a524"/><circle cx="24" cy="32" r="3" fill="#1a1206"/><circle cx="40" cy="32" r="3" fill="#1a1206"/><ellipse cx="32" cy="44" rx="9" ry="7" fill="#ffd89a"/><circle cx="32" cy="41" r="3" fill="#1a1206"/></svg>';
  function stCls(s){return s==='답변완료'?'ok':s==='상담중'?'run':'new'}
  function today(d){var t=new Date(),p=function(n){return String(n).padStart(2,'0')};return d===t.getFullYear()+'.'+p(t.getMonth()+1)+'.'+p(t.getDate())}
  function cnt(id,n){var el=document.getElementById(id);if(el)el.textContent=n}
  async function post(o){var r=await fetch(API,{method:'POST',body:JSON.stringify(o)});return r.json()}
  function br(t){return esc(t).replace(/\n/g,'<br>')}
  function draw(){var rows=ALL.filter(function(x){return F==='all'||x.status===F});
    if(!rows.length){list.innerHTML='<div class="bd-empty">'+BEAR+'<b>'+(ALL.length?'이 상태의 문의가 없어요':'아직 등록된 문의가 없어요')+'</b><span>'+(ALL.length?'다른 탭을 눌러 보세요.':'위에서 고미에게 첫 문의를 남겨 주세요. 빠른 시일 내에 연락드릴게요.')+'</span></div>';return}
    list.innerHTML=rows.map(function(x){return '<div class="bd-item"><button type="button" class="bd-row" data-no="'+esc(x.no)+'" aria-expanded="false"><span class="mono bd-no">'+String(x.no).padStart(3,'0')+'</span><span class="bd-t">'+LOCK+'<em>'+esc(x.title)+'</em>'+(x.comments?'<i class="bd-cc mono">💬 '+x.comments+'</i>':'')+(today(x.date)?'<i class="bd-newb mono">NEW</i>':'')+'</span><span class="bd-n">'+esc(x.name)+'</span><span class="mono bd-d">'+esc(x.date)+'</span><span><i class="bd-st '+stCls(x.status)+'">'+esc(x.status)+'</i></span></button><div class="bd-open" hidden></div></div>'}).join('')}
  async function loadBoard(){if(!list)return;var live=document.getElementById('bdLive');
    if(!API){list.innerHTML='<div class="bd-empty">'+BEAR+'<b>게시판을 준비하고 있어요</b><span>지금은 전화나 카카오톡으로 문의해 주세요.</span></div>';if(live)live.textContent='● READY';return}
    if(live){live.textContent='● SYNC…';live.classList.add('ing')}
    try{var r=await fetch(API+'?action=list&t='+Date.now());var j=await r.json();ALL=(j.ok&&j.list)||[];
      cnt('bdTotal',ALL.length);cnt('bdIng',ALL.filter(function(x){return x.status==='상담중'}).length);cnt('bdDone',ALL.filter(function(x){return x.status==='답변완료'}).length);
      var keep=[].map.call(list.querySelectorAll('.bd-row[aria-expanded="true"]'),function(b){return b.dataset.no});draw();
      if(live){live.textContent='● LIVE';live.classList.remove('ing')}}
    catch(e){list.innerHTML='<div class="bd-empty">'+BEAR+'<b>게시판을 불러오지 못했어요</b><span>잠시 후 새로고침해 주세요.</span></div>';if(live){live.textContent='● OFFLINE';live.classList.remove('ing')}}}
  function detail(box,j){var admin=!!j.admin;
    var th='';
    if(j.reply)th+=msg('admin',j.replyAt,j.reply);
    (j.comments||[]).forEach(function(c){th+=msg(c.who,c.date,c.text)});
    box.dataset.ok='1';
    box.innerHTML=(admin?'<div class="bd-admin-info"><span class="mono">ADMIN VIEW</span><b>'+esc(j.name)+'</b><span>📞 '+esc(j.tel||'-')+'</span>'+(j.want?'<span>🗓 '+esc(j.want)+'</span>':'')+'</div>':'')+
      '<div class="bd-chips">'+[j.svc,j.ind,j.len].filter(Boolean).map(function(c){return '<span>'+esc(c)+'</span>'}).join('')+'</div>'+
      '<div class="bd-thread">'+msg('customer',j.date,j.msg||'(내용 없음)',true)+th+(th?'':'<div class="bd-wait"><i></i><i></i><i></i><span>답변을 준비하고 있어요. 남겨주신 연락처로 먼저 연락드릴게요.</span></div>')+'</div>'+
      '<form class="bd-cmt"><textarea rows="2" maxlength="2000" required placeholder="'+(admin?'고객에게 남길 답변·댓글을 입력하세요':'추가로 궁금한 점이나 자료 안내를 남겨 주세요')+'" aria-label="댓글"></textarea>'+
      '<div class="bd-cmt-bar">'+(admin?'<label class="bd-stsel">상태 <select aria-label="상태"><option value="">그대로</option><option>접수</option><option>상담중</option><option>답변완료</option></select></label>':'<span class="bd-cmt-who">'+LOCK+' 글쓴이로 댓글 달기</span>')+'<button class="btn btn-honey btn-sm">'+(admin?'🐻 고미다로 답변 달기':'댓글 달기')+'</button></div><span class="bd-msg" role="status"></span></form>'}
  function msg(who,date,text,first){var me=who==='admin';return '<div class="bd-m '+(me?'a':'q')+'">'+(me?'<div class="bd-av">'+BEAR+'</div>':'')+'<div class="bd-b"><small class="mono">'+(me?'GOMIDA':(first?'QUESTION':'CUSTOMER'))+(date?' · '+esc(date):'')+'</small><p>'+br(text)+'</p></div></div>'}
  async function open(box,no){box.innerHTML='<p class="bd-loading mono">불러오는 중…</p>';
    try{var j=ADM?await post({action:'view',no:no,key:ADM}):await (await fetch(API+'?action=view&no='+encodeURIComponent(no)+'&pw='+encodeURIComponent(PWS[no])+'&t='+Date.now())).json();
      if(!j.ok){if(ADM){adminOut('관리자 비밀번호가 바뀌었어요. 다시 들어가 주세요.')}box.innerHTML='<p class="bd-loading">'+esc(j.error||'불러오지 못했어요')+'</p>';return}detail(box,j)}
    catch(e){box.innerHTML='<p class="bd-loading">불러오지 못했어요. 잠시 후 다시 시도해 주세요.</p>'}}
  function pwForm(box){box.innerHTML='<form class="bd-pw">'+LOCK+'<span class="bd-pw-t">비밀글이에요. 글을 쓸 때 정한 비밀번호를 입력해 주세요.</span><div class="bd-pw-f"><input type="password" required minlength="4" autocomplete="current-password" aria-label="비밀번호" placeholder="비밀번호"><button class="btn btn-honey btn-sm">확인</button></div><span class="bd-msg" role="status"></span></form>';box.querySelector('input').focus()}
  // 관리자 모드
  var adm=document.getElementById('bdAdmin');
  function adminUI(){if(!adm)return;var con=document.getElementById('bd');if(con)con.classList.toggle('is-admin',!!ADM);
    adm.innerHTML=ADM?'<span class="bd-admin-on mono">🔐 관리자 모드</span><span class="bd-admin-help">글을 누르면 전체 내용이 보이고 바로 답변을 달 수 있어요.</span><button type="button" class="bd-admin-btn" id="bdAdmOut">나가기</button>'
      :'<button type="button" class="bd-admin-btn" id="bdAdmIn">🔐 관리자</button>';
    var i=document.getElementById('bdAdmIn'),o=document.getElementById('bdAdmOut');
    if(i)i.onclick=function(){adm.innerHTML='<form class="bd-admin-form"><input type="password" required aria-label="관리자 비밀번호" placeholder="관리자 비밀번호" autocomplete="current-password"><button class="btn btn-honey btn-sm">들어가기</button><button type="button" class="bd-admin-btn" id="bdAdmX">취소</button><span class="bd-msg" role="status"></span></form>';
      var f=adm.querySelector('form');f.querySelector('input').focus();document.getElementById('bdAdmX').onclick=adminUI;
      f.onsubmit=async function(e){e.preventDefault();var k=f.querySelector('input').value,m=f.querySelector('.bd-msg');m.textContent='확인 중…';
        try{var j=await post({action:'admin',key:k});if(j.ok){ADM=k;try{sessionStorage.setItem('gmdAdm',k)}catch(_){}adminUI();draw()}else m.textContent='비밀번호가 맞지 않아요'}catch(_){m.textContent='확인하지 못했어요'}}};
    if(o)o.onclick=function(){adminOut()}}
  function adminOut(t){ADM='';try{sessionStorage.removeItem('gmdAdm')}catch(_){}adminUI();draw();if(t&&adm)adm.insertAdjacentHTML('beforeend','<span class="bd-msg">'+esc(t)+'</span>')}
  if(list){
    var rl=document.getElementById('bdReload');if(rl)rl.onclick=loadBoard;
    document.querySelectorAll('.bd-filter button').forEach(function(b){b.onclick=function(){F=b.dataset.f;document.querySelectorAll('.bd-filter button').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-selected',x===b)});draw()}});
    list.addEventListener('click',function(e){var b=e.target.closest('.bd-row[data-no]');if(!b)return;
      var box=b.nextElementSibling,isOpen=b.getAttribute('aria-expanded')==='true';b.setAttribute('aria-expanded',!isOpen);box.hidden=isOpen;
      if(!isOpen&&!box.dataset.ok){if(ADM||PWS[b.dataset.no])open(box,b.dataset.no);else pwForm(box)}});
    list.addEventListener('submit',async function(e){e.preventDefault();var f=e.target,box=f.closest('.bd-open'),no=box.previousElementSibling.dataset.no,m=f.querySelector('.bd-msg');
      if(f.classList.contains('bd-pw')){m.textContent='확인 중…';PWS[no]=await hash(f.querySelector('input').value);
        var j=await (await fetch(API+'?action=view&no='+encodeURIComponent(no)+'&pw='+encodeURIComponent(PWS[no])+'&t='+Date.now())).json().catch(function(){return{ok:false}});
        if(!j.ok){delete PWS[no];m.textContent=j.error||'비밀번호가 맞지 않아요';return}detail(box,j);return}
      if(f.classList.contains('bd-cmt')){var ta=f.querySelector('textarea'),sel=f.querySelector('select'),btn=f.querySelector('button');var text=ta.value.trim();if(!text&&!(sel&&sel.value)){ta.focus();return}
        btn.disabled=true;m.textContent='올리는 중…';
        try{var o={action:'comment',no:no,text:text};if(ADM)o.key=ADM;else o.pw=PWS[no];if(sel&&sel.value)o.status=sel.value;
          var r=await post(o);if(!r.ok){m.textContent=r.error||'올리지 못했어요';btn.disabled=false;return}
          detail(box,r);var x=ALL.filter(function(z){return String(z.no)===String(no)})[0];if(x){x.status=r.status;x.comments=(r.comments||[]).length+(r.reply?1:0);var row=box.previousElementSibling;var st=row.querySelector('.bd-st');st.className='bd-st '+stCls(r.status);st.textContent=r.status}cnt('bdIng',ALL.filter(function(z){return z.status==='상담중'}).length);cnt('bdDone',ALL.filter(function(z){return z.status==='답변완료'}).length);
          var last=box.querySelector('.bd-thread .bd-m:last-child');if(last)last.classList.add('fresh')}
        catch(_){m.textContent='올리지 못했어요. 잠시 후 다시 시도해 주세요.';btn.disabled=false}}});
    adminUI();loadBoard();
  }
})();

(function(){
  // ---- AI 상담 접수 (고미가 듣는 대화형 문의) ----
  var ik=document.getElementById('intake'),form=document.getElementById('qform');if(!ik||!form)return;
  var LOG=document.getElementById('ikLog'),IN=document.getElementById('ikIn'),ST=document.getElementById('ikState'),WAVE=document.getElementById('ikWave'),ORB=document.getElementById('ikOrb');
  var DL=document.getElementById('ikDl'),TAGS=document.getElementById('ikTags'),BAR=document.getElementById('ikBar'),PCT=document.getElementById('ikPct'),ALOG=document.getElementById('ikAlog'),REC=document.getElementById('ikRec');
  var classic=document.getElementById('ikClassic'),sw=document.getElementById('ikSwitch'),toForm=document.getElementById('ikToForm'),toChat=document.getElementById('ikToChat');
  var API=form.dataset.api||'';
  var rm=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
  function $(id){return document.getElementById(id)}
  function esc(t){return String(t==null?'':t).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  function opts(id){return [].map.call($(id).options,function(o){return o.value||o.textContent})}
  ik.hidden=false;sw.hidden=false;classic.hidden=true;
  toForm.onclick=function(){classic.hidden=false;ik.hidden=true;toForm.hidden=true;toChat.hidden=false;sync();classic.scrollIntoView({behavior:rm?'auto':'smooth',block:'start'})};
  toChat.onclick=function(){classic.hidden=true;ik.hidden=false;toForm.hidden=false;toChat.hidden=true};
  var A={};
  function sync(){[['n','name'],['t','tel'],['s','svc'],['i','ind'],['l','len'],['d','date'],['m','msg']].forEach(function(p){if(A[p[1]]!=null&&$(p[0]))$(p[0]).value=A[p[1]]})}
  // 상태 표시: listening / hearing / thinking
  var hearT;function state(s){ST.textContent=s==='think'?'● THINKING…':s==='hear'?'● HEARING':s==='done'?'● RECEIVED':'● LISTENING';ik.dataset.st=s}
  function hear(){state('hear');[].forEach.call(WAVE.children,function(b){b.style.transform='scaleY('+(0.25+Math.random()*1.1).toFixed(2)+')'});clearTimeout(hearT);hearT=setTimeout(function(){state('listen');[].forEach.call(WAVE.children,function(b){b.style.transform=''})},450)}
  function scroll(){LOG.scrollTop=LOG.scrollHeight}
  var live=false;
  function settle(){requestAnimationFrame(function(){scroll();if(!live)return;var r=IN.getBoundingClientRect(),vh=window.innerHeight;
    if(r.bottom>vh-8)window.scrollBy({top:r.bottom-vh+16,behavior:rm?'auto':'smooth'});else{var c=ik.querySelector('.ik-chat').getBoundingClientRect();if(c.top<64&&r.bottom<vh*0.5)window.scrollBy({top:c.top-80,behavior:rm?'auto':'smooth'})}})}
  if('ResizeObserver' in window){var ro=new ResizeObserver(function(){scroll()});ro.observe(IN);ro.observe(LOG)}
  function bot(html,delay){return new Promise(function(res){state('think');var t=document.createElement('div');t.className='ik-msg bot typing';t.innerHTML='<span class="ik-dots"><i></i><i></i><i></i></span>';LOG.appendChild(t);scroll();
    setTimeout(function(){t.classList.remove('typing');t.innerHTML='<p>'+html+'</p>';scroll();settle();state('listen');res()},rm?0:(delay||700))})}
  function me(text){live=true;var d=document.createElement('div');d.className='ik-msg me';d.innerHTML='<p>'+esc(text)+'</p>';LOG.appendChild(d);scroll()}
  function alog(t){var p=document.createElement('p');p.textContent='▸ '+t;ALOG.appendChild(p);while(ALOG.children.length>6)ALOG.removeChild(ALOG.firstChild);ALOG.scrollTop=ALOG.scrollHeight}
  // 키워드 이해
  var KW=[[/신메뉴|신상|출시|새로 나온|신제품/,'신메뉴·신상품'],[/오픈|개업|새로 열|그랜드/,'오픈 홍보'],[/할인|이벤트|쿠폰|증정|%|프로모션/,'이벤트·할인'],[/릴스|인스타/,'인스타 릴스'],[/쇼츠|유튜브/,'유튜브 쇼츠'],[/틱톡/,'틱톡'],[/상세페이지|스마트스토어|쇼핑몰/,'상세페이지'],[/모델|가상모델|인물/,'AI 모델'],[/가격|비용|견적|얼마|예산/,'가격 문의'],[/급해|급함|빨리|이번 ?주|내일|당장/,'급한 일정'],[/사진/,'사진 보유'],[/로고/,'로고 보유'],[/감성|따뜻|아늑/,'따뜻한 무드'],[/고급|프리미엄|럭셔리/,'고급스러운 무드'],[/트렌디|힙|요즘/,'트렌디 무드'],[/전단|배너|썸네일|포스터/,'이미지 소재'],[/광고비|마케팅|홍보/,'홍보 목적'],[/매장|가게|손님/,'매장 방문 유도']];
  function tagsOf(t){var o=[];KW.forEach(function(k){if(k[0].test(t)&&o.indexOf(k[1])<0)o.push(k[1])});return o}
  function drawTags(list){TAGS.innerHTML=list.length?list.map(function(t){return '<span>#'+esc(t)+'</span>'}).join(''):'<span class="ikb-ph">이야기를 들려주시면 핵심 키워드를 뽑아 둘게요</span>'}
  var FIELDS=[['name','이름/상호'],['tel','연락처'],['svc','관심 서비스'],['ind','업종'],['len','영상 길이'],['date','희망 일정']];
  function brief(){DL.innerHTML=FIELDS.map(function(f){var v=A[f[0]];if(f[0]==='tel'&&v)v=v.replace(/(\d{3})[- ]?(\d{3,4})[- ]?(\d{4})/,'$1-****-$3');return '<div class="'+(v?'on':'')+'"><dt>'+f[1]+'</dt><dd>'+(v?esc(v):'<i>듣는 중…</i>')+'</dd></div>'}).join('');
    var tot=STEPS.length-1,done=Math.min(tot,step);var pc=Math.round(done/tot*100);BAR.style.width=pc+'%';PCT.textContent=pc+'%';
    if(A.svc&&A.svc!=='잘 모르겠어요'){REC.hidden=false;$('ikRecT').textContent=A.svc+(A.len&&A.len!=='상담 후 결정'?' · '+A.len:'');$('ikRecD').textContent=A.ind?A.ind+' 업종에 맞춘 구성으로 견적을 준비할게요':'업종을 알려주시면 구성을 맞춰 볼게요'}
    else if(A.svc){REC.hidden=false;$('ikRecT').textContent='맞춤 추천 예정';$('ikRecD').textContent='이야기를 들어보고 딱 맞는 상품을 골라 드릴게요'}}
  // 입력 위젯
  function textIn(o){return new Promise(function(res){IN.innerHTML='<form class="ik-form"><'+(o.area?'textarea rows="3"':'input')+' id="ikTxt" '+(o.type?'type="'+o.type+'" ':'')+(o.mode?'inputmode="'+o.mode+'" ':'')+'placeholder="'+esc(o.ph||'')+'" autocomplete="'+(o.ac||'off')+'" aria-label="'+esc(o.label||o.ph||'답변')+'">'+(o.area?'</textarea>':'')+'<button class="ik-send" aria-label="보내기">↑</button></form>'+(o.skip?'<button type="button" class="ik-chip ik-skip">'+esc(o.skip)+'</button>':'');
    var f=IN.querySelector('form'),x=$('ikTxt');settle();setTimeout(function(){x.focus({preventScroll:true})},50);
    x.addEventListener('focus',settle);
    x.addEventListener('input',function(){hear();if(o.area){x.style.height='auto';x.style.height=Math.min(x.scrollHeight,200)+'px'}if(o.live)o.live(x.value)});
    if(o.area)x.addEventListener('keydown',function(e){if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();f.requestSubmit()}});
    f.onsubmit=function(e){e.preventDefault();var v=x.value.trim();var err=o.check&&o.check(v);if(err){x.setCustomValidity(err);x.reportValidity();x.setCustomValidity('');return}IN.innerHTML='';res(v)};
    var sk=IN.querySelector('.ik-skip');if(sk)sk.onclick=function(){IN.innerHTML='';res('')}})}
  function chipIn(list,o){o=o||{};return new Promise(function(res){IN.innerHTML='<div class="ik-chips'+(list.length>8?' many':'')+'" role="group" aria-label="'+esc(o.label||'선택')+'">'+list.map(function(c){return '<button type="button" class="ik-chip">'+esc(c)+'</button>'}).join('')+'</div>';
    IN.querySelectorAll('.ik-chip').forEach(function(b){b.onclick=function(){IN.innerHTML='';res(b.textContent)}});settle();var first=IN.querySelector('.ik-chip');if(first)first.focus({preventScroll:true})})}
  function dateIn(){return new Promise(function(res){IN.innerHTML='<form class="ik-form"><input id="ikDate" type="date" aria-label="희망 일정"><button class="ik-send" aria-label="보내기">↑</button></form><button type="button" class="ik-chip ik-skip">아직 정하지 않았어요</button>';
    settle();var f=IN.querySelector('form');f.onsubmit=function(e){e.preventDefault();var v=$('ikDate').value;if(!v){$('ikDate').focus();return}IN.innerHTML='';res(v)};IN.querySelector('.ik-skip').onclick=function(){IN.innerHTML='';res('')}})}
  var step=0,STEPS;
  STEPS=[
   async function(){await bot('안녕하세요! 고미다의 AI 상담 곰 <b>고미</b>예요 🐻',500);await bot('어떤 광고가 필요하신지 제가 차근차근 여쭤볼게요. 편하게 답해 주시면 돼요.',800);await bot('먼저, 어떻게 불러드리면 될까요? <span class="ik-sub">이름이나 가게 이름</span>');
     var v=await textIn({ph:'예: 고미네 국밥 / 박영태',ac:'name',check:function(v){return v?'':'이름이나 상호를 알려주세요'}});me(v);A.name=v;alog('고객 인식: '+v)},
   async function(){await bot(esc(A.name)+'님, 반가워요! 연락드릴 번호를 알려주세요.');
     var v=await textIn({ph:'010-0000-0000',type:'tel',mode:'tel',ac:'tel',check:function(v){return (v.replace(/\D/g,'').length>=9)?'':'연락받으실 번호를 확인해 주세요'}});me(v);A.tel=v;alog('연락처 확인 완료')},
   async function(){await bot('어떤 걸 만들고 싶으세요?');var v=await chipIn(opts('s'),{label:'관심 서비스'});me(v);A.svc=v;alog('관심 서비스: '+v)},
   async function(){await bot('어떤 업종이세요?');var v=await chipIn(opts('i'),{label:'업종'});me(v);A.ind=v;alog('업종 인식: '+v)},
   async function(){await bot(A.svc==='썸네일·배너'||A.svc==='AI 비주얼'?'영상도 함께 필요하시면 길이를 골라 주세요.':'영상 길이는 어느 정도가 좋을까요?');var v=await chipIn(opts('l'),{label:'영상 길이'});me(v);A.len=v},
   async function(){await bot('언제까지 받아보고 싶으세요?');var v=await dateIn();me(v?v.replace(/-/g,'.')+'까지':'아직 정하지 않았어요');A.date=v;if(v){var dd=Math.ceil((new Date(v)-new Date())/864e5);alog(dd>=0?'일정: D-'+dd:'일정 확인 필요')}},
   async function(){await bot('이제 제일 중요한 이야기예요. 가게나 상품을 소개해 주시고, 이번 광고로 무엇을 알리고 싶은지 들려주세요. <span class="ik-sub">자세할수록 더 잘 맞춰 드려요 · 참고 영상 링크도 좋아요</span>',900);
     var v=await textIn({area:1,ph:'예: 동탄에서 네일샵을 해요. 이번 달 오픈 이벤트(첫 방문 20%)를 인스타 릴스로 알리고 싶어요. 매장 사진은 있어요.',label:'문의 내용',check:function(v){return v.length>=5?'':'조금만 더 이야기해 주세요'},live:function(t){drawTags(tagsOf(t))}});
     me(v);A.msg=v;var tg=tagsOf(v);drawTags(tg);alog('핵심 키워드 '+tg.length+'개 추출');
     var r=tg.length?'잘 들었어요. '+tg.slice(0,3).map(function(t){return '<b>‘'+esc(t)+'’</b>'}).join(', ')+' 이야기가 핵심이네요.':'잘 들었어요. 꼼꼼히 메모해 뒀어요.';
     if(tg.indexOf('가격 문의')>=0)r+=' 가격은 구성에 따라 달라서, 연락드릴 때 딱 맞는 견적으로 알려드릴게요.';
     if(tg.indexOf('사진 보유')>=0||tg.indexOf('로고 보유')>=0)r+=' 갖고 계신 자료는 연락드릴 때 받아볼게요.';
     if(tg.indexOf('급한 일정')>=0)r+=' 일정이 급하시군요. 우선순위로 확인할게요.';
     await bot(r,1100)},
   async function(){await bot('마지막이에요. 나중에 이 문의와 답변을 다시 볼 때 쓸 <b>비밀번호</b>를 정해 주세요. <span class="ik-sub">숫자 4자리 이상</span>');
     var v=await textIn({ph:'비밀번호 4자리 이상',type:'password',mode:'numeric',ac:'new-password',label:'글 비밀번호',check:function(v){return v.length>=4?'':'4자리 이상으로 정해 주세요'}});me('••••');$('pw').value=v;alog('비밀글 잠금 설정')},
   async function(){await bot(esc(A.name)+'님 이야기를 「고미가 이해한 내용」에 정리했어요. 맞으면 보내 주세요. <span class="ik-sub">보내기를 누르면 <a href="'+(document.querySelector('a[href*="privacy"]')||{}).href+'" target="_blank" rel="noopener">개인정보 수집·이용</a>에 동의하시는 거예요.</span>');
     var v=await chipIn(['동의하고 고미에게 보내기 →','처음부터 다시 쓸래요'],{label:'보내기'});
     if(v.indexOf('다시')>=0){me(v);return restart()}
     me('보낼게요!');sync();
     if(!API){await bot('앗, 지금은 온라인 접수를 준비하는 중이라 바로 전달이 어려워요. 아래 버튼으로 내용을 복사해서 카카오톡이나 문자로 보내 주시면 바로 답할게요.');IN.innerHTML='<button type="button" class="ik-chip" id="ikCopy">📋 내용 복사하기</button>';$('ikCopy').onclick=function(){var t='[고미다 문의]\n이름: '+A.name+'\n연락처: '+A.tel+'\n서비스: '+A.svc+'\n업종: '+A.ind+'\n길이: '+A.len+'\n일정: '+(A.date||'미정')+'\n내용: '+A.msg;navigator.clipboard&&navigator.clipboard.writeText(t).then(function(){$('ikCopy').textContent='✓ 복사됐어요'})};return}
     state('think');alog('고미다로 전달 중…');var chk=form.querySelector('input[type=checkbox][required]');if(chk)chk.checked=true;
     var waiter=new Promise(function(res){form.addEventListener('qresult',function h(e){form.removeEventListener('qresult',h);res(e.detail)})});
     form.requestSubmit();var j=await waiter;
     if(j&&j.ok){state('done');ik.classList.add('sent');BAR.style.width='100%';PCT.textContent='100%';alog('접수 완료 · 문의 #'+j.no);
       await bot('접수됐어요! 🎉 <b>문의 #'+j.no+'</b>로 등록됐어요.',600);await bot('빠른 시일 내에 남겨주신 번호로 연락드릴게요. 아래 <a href="#board">문의 게시판</a>에서 비밀번호로 답변도 확인하실 수 있어요.',900);
       IN.innerHTML='<div class="ik-chips"><button type="button" class="ik-chip" id="ikNew">새 문의 남기기</button><a class="ik-chip" href="#board">게시판에서 확인 ↓</a></div>';$('ikNew').onclick=restart}
     else{await bot('전달 중에 문제가 생겼어요 😢 잠시 후 다시 보내 주시거나, 카카오톡·전화로 연락 주세요.');IN.innerHTML='<button type="button" class="ik-chip" id="ikRetry">다시 보내기</button>';$('ikRetry').onclick=function(){step=STEPS.length-1;run()}}}
  ];
  async function run(){while(step<STEPS.length){brief();await STEPS[step]();step++;brief()}}
  function restart(){A={};step=0;LOG.innerHTML='';drawTags([]);REC.hidden=true;ik.classList.remove('sent');ALOG.innerHTML='<p>▸ 새 상담 세션 시작</p>';run()}
  // 처음 화면에 들어왔을 때 대화 시작 (화면 밖이면 대기)
  var started=false;function go(){if(started)return;started=true;brief();run()}
  if('IntersectionObserver' in window){new IntersectionObserver(function(es,o){if(es[0].isIntersecting){o.disconnect();go()}},{threshold:.25}).observe(ik)}else go();
})();
